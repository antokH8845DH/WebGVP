<?php

namespace App\Controllers;

class News extends BaseController
{
    public function index()
    {
        // return view('welcome_message');
        return view('news');
    }

    //--------------------------------------------------------------------

}
