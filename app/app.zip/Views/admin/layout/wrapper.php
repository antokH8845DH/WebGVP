<?= $this->include('admin/layout/head'); ?>
<?= $this->include('admin/layout/nav'); ?>


<?= $this->renderSection('adminContent') ?>
<?= $this->include('admin/layout/footer'); ?>