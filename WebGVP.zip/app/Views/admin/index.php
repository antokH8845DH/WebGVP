<?= $this->extend('admin/layout/wrapper') ?>

<?= $this->section('adminContent') ?>
<H1>INI ADMIN</H1>
<?= $this->endSection(); ?>