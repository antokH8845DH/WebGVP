<?php

namespace App\Controllers;

class Career extends BaseController
{
    public function index()
    {
        // return view('welcome_message');
        return view('career');
    }

    //--------------------------------------------------------------------

}
