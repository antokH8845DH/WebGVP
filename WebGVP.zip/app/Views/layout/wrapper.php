<?= $this->include('layout/v_head'); ?>
<?= $this->include('layout/v_header'); ?>


<?= $this->renderSection('content') ?>
<?= $this->include('layout/v_footer'); ?>
