<?php

namespace App\Entities;

use CodeIgniter\Entity;

class ProductDetail extends Entity
{

    // public function setProfile($sfile)
    // {
    //     $fileName = $sfile->getRandomName();
    //     $writePath = './profile';
    //     $sfile->move($writePath, $fileName);
    //     $this->attributes['profile'] = $fileName;
    //     return $this;
    // }
}
