<?php

namespace App\Controllers;

class AboutUs extends BaseController
{
    public function index()
    {
        // return view('welcome_message');
        return view('aboutUs');
    }

    //--------------------------------------------------------------------

}
